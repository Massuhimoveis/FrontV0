'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Moon, Sun, LogOut, Menu, X, User, Home, Ticket, ChevronLeft, ChevronRight, Car, DollarSign, Edit, Plus, Trash, Check, HelpCircle, AlertTriangle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"

// Simulated client data
const clientsData = [
  { 
    id: 1, 
    name: "Alex", 
    phone: "+556181495065", 
    email: "alex@example.com", 
    status: "LEAD",
    lastEditDate: "28/10/2024",
    propertyBuying: { 
      budget: { type: 'range', exigencia: 500000, preferencia: 550000 },
      preferredLocation: "Centro",
      squareMeterValue: { type: 'range', exigencia: 9000, preferencia: 11000 },
      paymentMethod: "Financiamento",
      valueObservations: "Negociável",
      minArea: 50,
      bedrooms: { 
        type: 'multipleChoice',
        options: ['1', '2', '3', '4+'],
        requirements: ['2'],
        preferences: ['2', '3']
      },
      suites: { 
        type: 'multipleChoice',
        options: ['0', '1', '2', '3+'],
        requirements: [],
        preferences: ['1']
      },
      bathrooms: { 
        type: 'multipleChoice',
        options: ['1', '2', '3', '4+'],
        requirements: ['2'],
        preferences: ['2', '3']
      },
      maidRoom: false,
      kitchenType: "Americana",
      elevator: true,
      floorPreference: { 
        type: 'multipleChoice',
        options: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10+'],
        requirements: [],
        preferences: ['5', '6', '7', '8', '9', '10+']
      }
    },
    carBuying: { 
      model: "SUV", 
      maxPrice: 80000,
      preferredBrands: ["Toyota", "Honda"],
      fuelType: "Flex",
      yearMin: 2018
    },
    propertySelling: { 
      address: "Rua A, 123", 
      askingPrice: 450000,
      propertyType: "Apartamento",
      area: 100,
      bedrooms: 3,
      bathrooms: 2
    },
  },
  { id: 2, name: "Maria", phone: "+556187654321", email: "maria@example.com", status: "PROSPECT", lastEditDate: "29/10/2024" },
  { id: 3, name: "João", phone: "+556189876543", email: "joao@example.com", status: "CLIENT", lastEditDate: "30/10/2024" },
]

// Simulated ticket data
const ticketsData = [
  { id: 1, clientId: 1, type: "propertyBuying", status: "ATENDE", details: "Apartamento 2 quartos, Centro", title: "IMÓVEL NO PERFIL", date: "30/10/2024", dataPrincipal: "29/10/2024 10:11", dataReserva: "30/10/2024 10:11" },
  { id: 2, clientId: 1, type: "carBuying", status: "EM ANÁLISE", details: "SUV, até R$ 80.000", title: "CARRO NO PERFIL", date: "30/10/2024" },
  { id: 3, clientId: 1, type: "propertySelling", status: "ABERTO", details: "Venda concluída", title: "VENDA DE IMÓVEL", date: "31/10/2024" },
  { id: 4, clientId: 2, type: "propertyBuying", status: "NÃO ATENDE", details: "Casa 3 quartos, Jardim Botânico", title: "IMÓVEL FORA DO PERFIL", date: "01/11/2024" },
  { id: 5, clientId: 3, type: "carBuying", status: "ENVIADO E AGUARDANDO RETORNO", details: "Sedan, até R$ 100.000", title: "CARRO LUXO", date: "02/11/2024" },
]

// Predefined fields for each profile type
const predefinedFields = {
  propertyBuying: [
    "Valor acima do orçamento",
    "Localização não desejada",
    "Tamanho inadequado",
    "Falta de características desejadas",
    "Condições de pagamento incompatíveis",
    "Outro"
  ],
  carBuying: [
    "Preço acima do orçamento",
    "Modelo indisponível",
    "Marca não preferida",
    "Ano do veículo inadequado",
    "Tipo de combustível incompatível",
    "Outro"
  ],
  propertySelling: [
    "Valor de venda abaixo do esperado",
    "Localização não atrativa para compradores",
    "Tamanho do imóvel inadequado para o mercado",
    "Condições do imóvel não satisfatórias",
    "Documentação incompleta",
    "Outro"
  ]
}

const addMotivoNaoAtende = (motivo, detalhe) => {
  const updatedClient = { ...selectedClient };
  if (!updatedClient[currentProfileType]) {
    updatedClient[currentProfileType] = {};
  }
  updatedClient[currentProfileType].motivosNaoAtende = updatedClient[currentProfileType].motivosNaoAtende || [];
  updatedClient[currentProfileType].motivosNaoAtende.push({ motivo, detalhe });
  setSelectedClient(updatedClient);

  // Atualizar o clientsData
  const updatedClientsData = clientsData.map(c => c.id === selectedClient.id ? updatedClient : c);
  clientsData.splice(0, clientsData.length, ...updatedClientsData);
};

export default function Component() {
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(true)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [selectedClient, setSelectedClient] = useState(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState(null)
  const [isEditing, setIsEditing] = useState(false)
  const [editedProfile, setEditedProfile] = useState({})
  const [pendingTickets, setPendingTickets] = useState({ propertyBuying: 0, carBuying: 0, propertySelling: 0 })
  const [selectedPredefinedField, setSelectedPredefinedField] = useState("")
  const [predefinedFieldValue, setPredefinedFieldValue] = useState("")
  const [currentProfileType, setCurrentProfileType] = useState("propertyBuying")
  const [ticketFilter, setTicketFilter] = useState("active")

  useEffect(() => {
    const handleResize = () => {
      setIsFullscreen(window.innerWidth >= 768)
    }
    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    if (selectedClient) {
      updatePendingTickets()
      setEditedProfile(selectedClient[currentProfileType] || {})
    }
  }, [selectedClient, currentProfileType])

  const toggleLeftPanel = () => setIsLeftPanelOpen(!isLeftPanelOpen)
  const toggleDarkMode = () => setIsDarkMode(!isDarkMode)

  const handleClientSelect = (client) => {
    setSelectedClient(client)
    setSelectedTicket(null)
    setIsEditing(false)
    setEditedProfile(client[currentProfileType] || {})
    if (window.innerWidth < 768) {
      setIsLeftPanelOpen(false)
    }
  }

  const handleTicketSelect = (ticket) => {
    setSelectedTicket(prevTicket => prevTicket && prevTicket.id === ticket.id ? null : ticket)
  }

  const handleTicketStatusChange = (ticketId, newStatus) => {
    console.log(`Updating ticket ${ticketId} status to ${newStatus}`)
    const updatedTicketsData = ticketsData.map(ticket => {
      if (ticket.id === ticketId) {
        const updatedTicket = { ...ticket, status: newStatus }
        if (newStatus === "EM ANÁLISE") {
          updatedTicket.previousStatus = "ABERTO"
        } else if (["ENVIADO E AGUARDANDO RETORNO", "NÃO ATENDE", "ATENDE"].includes(newStatus)) {
          updatedTicket.previousStatus = ticket.status
        }
        return updatedTicket
      }
      return ticket
    })
    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData)
    
    setSelectedTicket(prevTicket => {
      if (prevTicket && prevTicket.id === ticketId) {
        const updatedTicket = { ...prevTicket, status: newStatus }
        if (newStatus === "EM ANÁLISE") {
          updatedTicket.previousStatus = "ABERTO"
        } else if (["ENVIADO E AGUARDANDO RETORNO", "NÃO ATENDE", "ATENDE"].includes(newStatus)) {
          updatedTicket.previousStatus = prevTicket.status
        }
        return updatedTicket
      }
      return prevTicket
    })
    
    updatePendingTickets()
  }

  const handleEditToggle = () => {
    setIsEditing(!isEditing)
  }

  const handleProfileChange = (field, value) => {
    setEditedProfile(prevProfile => {
      const updatedProfile = { ...prevProfile, [field]: value }
      // Update the client data
      const updatedClientsData = clientsData.map(client => 
        client.id === selectedClient.id ? { ...client, [currentProfileType]: updatedProfile } : client
      )
      clientsData.splice(0, clientsData.length, ...updatedClientsData)
      return updatedProfile
    })
  }

  const handleAddPredefinedField = () => {
    if (selectedPredefinedField && predefinedFieldValue) {
      handleProfileChange(selectedPredefinedField, predefinedFieldValue)
      setSelectedPredefinedField("")
      setPredefinedFieldValue("")
    }
  }

  const handleRemoveField = (field) => {
    const updatedProfile = { ...editedProfile }
    delete updatedProfile[field]
    setEditedProfile(updatedProfile)
    // Update the client data
    const updatedClientsData = clientsData.map(client => 
      client.id === selectedClient.id ? { ...client, [currentProfileType]: updatedProfile } : client
    )
    clientsData.splice(0, clientsData.length, ...updatedClientsData)
  }

  const handleDateChange = (ticketId, newDate) => {
    console.log(`Updating ticket ${ticketId} date to ${newDate}`)
    const [year, month, day] = newDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;
    const updatedTicketsData = ticketsData.map(ticket => 
      ticket.id === ticketId ? { ...ticket, date: formattedDate } : ticket
    )
    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData)
    
    setSelectedTicket(prevTicket => {
      if (prevTicket && prevTicket.id === ticketId) {
        return { ...prevTicket, date: formattedDate }
      }
      return prevTicket
    })
    
    updatePendingTickets()
  }

  const handleClientDateChange = (clientId, newDate) => {
    const [year, month, day] = newDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;
    const updatedClientsData = clientsData.map(client => 
      client.id === clientId ? { ...client, lastEditDate: formattedDate } : client
    );
    clientsData.splice(0, clientsData.length, ...updatedClientsData);
  }

  const updatePendingTickets = () => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const pending = { propertyBuying: 0, carBuying: 0, propertySelling: 0 }
    ticketsData.forEach(ticket => {
      if (ticket.clientId === selectedClient.id) {
        const [day, month, year] = ticket.date.split('/')
        const ticketDate = new Date(year, month - 1, day)
        ticketDate.setHours(0, 0, 0, 0)
        if (
          ticket.status === "ABERTO" || 
          ticket.status === "EM ANÁLISE" ||
          ticket.status === "ENVIADO E AGUARDANDO RETORNO" ||
          (ticket.status === "ATENDE" && !ticket.dataPrincipal) ||
          (ticket.status === "NÃO ATENDE" && !ticket.motivoNaoAtende) ||
          ticketDate < today
        ) {
          pending[ticket.type]++
        }
      }
    })
    setPendingTickets(pending)
  }

  const getDateColor = (date) => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const [day, month, year] = date.split('/')
    const ticketDate = new Date(year, month - 1, day)
    ticketDate.setHours(0, 0, 0, 0)
    
    if (ticketDate < today) return 'text-red-500'
    if (ticketDate.getTime() === today.getTime()) return 'text-yellow-500'
    return 'text-green-500'
  }

  const renderProfileFields = () => {
    return (
      <div className="space-y-4">
        {Object.entries(editedProfile).map(([field, value]) => (
          <div key={field} className="space-y-2">
            <Label htmlFor={field} className="text-lg font-semibold">{field}</Label>
            {typeof value === 'object' && value.type === 'multipleChoice' ? (
              <div className="relative">
                <Button
                  variant="outline"
                  className="w-full text-left justify-start"
                  onMouseEnter={() => document.getElementById(`popup-${field}`).classList.remove('hidden')}
                  onMouseLeave={() => document.getElementById(`popup-${field}`).classList.add('hidden')}
                >
                  {value.requirements.length > 0 ? `Exigências: ${value.requirements.join(', ')}` : 'Sem exigências'}
                  {value.preferences.length > 0 && ` | Preferências: ${value.preferences.join(', ')}`}
                </Button>
                <div
                  id={`popup-${field}`}
                  className="absolute z-10 w-full bg-white border rounded-md shadow-lg hidden"
                  onMouseEnter={(e) => e.currentTarget.classList.remove('hidden')}
                  onMouseLeave={(e) => e.currentTarget.classList.add('hidden')}
                >
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Opção</TableHead>
                        <TableHead>Exigência</TableHead>
                        <TableHead>Preferência</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {value.options.map((option, index) => (
                        <TableRow key={index}>
                          <TableCell>{option}</TableCell>
                          <TableCell>
                            <Checkbox
                              checked={value.requirements.includes(option)}
                              onCheckedChange={(checked) => {
                                const newRequirements = checked
                                  ? [...value.requirements, option]
                                  : value.requirements.filter(req => req !== option)
                                handleProfileChange(field, { ...value, requirements: newRequirements })
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Checkbox
                              checked={value.preferences.includes(option)}
                              onCheckedChange={(checked) => {
                                const newPreferences = checked
                                  ? [...value.preferences, option]
                                  : value.preferences.filter(pref => pref !== option)
                                handleProfileChange(field, { ...value, preferences: newPreferences })
                              }}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            ) : typeof value === 'object' && value.type === 'range' ? (
              <div className="flex space-x-4">
                <div className="flex-1">
                  <Label htmlFor={`${field}-exigencia`}>Exigência</Label>
                  <Input
                    id={`${field}-exigencia`}
                    type="number"
                    value={value.exigencia || ''}
                    onChange={(e) => handleProfileChange(field, { ...value, exigencia: e.target.value })}
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor={`${field}-preferencia`}>Preferência</Label>
                  <Input
                    id={`${field}-preferencia`}
                    type="number"
                    value={value.preferencia || ''}
                    onChange={(e) => handleProfileChange(field, { ...value, preferencia: e.target.value })}
                  />
                </div>
              </div>
            ) : (
              <Input
                id={field}
                type={typeof value === 'number' ? 'number' : 'text'}
                value={value}
                onChange={(e) => handleProfileChange(field, e.target.value)}
              />
            )}
          </div>
        ))}
        {editedProfile.motivosNaoAtende && editedProfile.motivosNaoAtende.length > 0 && (
          <div className="space-y-2">
            <Label className="text-lg font-semibold">Motivos de Não Atendimento</Label>
            <ul className="list-disc list-inside">
              {editedProfile.motivosNaoAtende.map((item, index) => (
                <li key={index}>{item.motivo}: {item.detalhe}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    )
  }

  const renderPredefinedFieldsSelector = () => {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Select
            onValueChange={setSelectedPredefinedField}
            value={selectedPredefinedField}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Selecione um campo" />
            </SelectTrigger>
            <SelectContent>
              {predefinedFields[currentProfileType].map((field) => (
                <SelectItem key={field} value={field}>{field}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {selectedPredefinedField && (
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Valor do campo"
              value={predefinedFieldValue}
              onChange={(e) => setPredefinedFieldValue(e.target.value)}
              className="flex-grow"
            />
            <Button onClick={handleAddPredefinedField}>
              <Plus className="mr-2 h-4 w-4" />
              Adicionar
            </Button>
          </div>
        )}
      </div>
    )
  }

  const renderTickets = (type) => {
    const clientTickets = ticketsData.filter(ticket => 
      ticket.clientId === selectedClient.id && 
      ticket.type === type &&
      (ticketFilter === "active" ? ticket.status !== "DESCARTADO" : ticket.status === "DESCARTADO")
    )
    return (
      <div className="mt-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">Tickets</h3>
          <Select
            onValueChange={setTicketFilter}
            value={ticketFilter}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filtrar tickets" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Ativos</SelectItem>
              <SelectItem value="discarded">Descartados</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {clientTickets.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>TÍTULO</TableHead>
                <TableHead>DATA</TableHead>
                <TableHead>SITUAÇÃO</TableHead>
                <TableHead>PENDÊNCIA</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clientTickets.map((ticket) => (
                <TableRow key={ticket.id} className="cursor-pointer" onClick={() => handleTicketSelect(ticket)}>
                  <TableCell>{ticket.title}</TableCell>
                  <TableCell>
                    <Input
                      type="date"
                      defaultValue={ticket.date.split('/').reverse().join('-')}
                      className={getDateColor(ticket.date)}
                      onChange={(e) => handleDateChange(ticket.id, e.target.value)}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </TableCell>
                  <TableCell>
                    <Select 
                      onValueChange={(value) => handleTicketStatusChange(ticket.id, value)} 
                      defaultValue={ticket.status}
                      onClick={(e) => e.stopPropagation()}
                      disabled={ticketFilter === "discarded"}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Selecione o status" />
                      </SelectTrigger>
                      <SelectContent>
                        {ticket.status === "ABERTO" && <SelectItem value="ABERTO">ABERTO</SelectItem>}
                        {(ticket.status === "ABERTO" || ticket.status === "EM ANÁLISE") && <SelectItem value="EM ANÁLISE">EM ANÁLISE</SelectItem>}
                        {!["NÃO ATENDE", "ATENDE"].includes(ticket.status) && <SelectItem value="ENVIADO E AGUARDANDO RETORNO">ENVIADO E AGUARDANDO RETORNO</SelectItem>}
                        <SelectItem value="ATENDE">ATENDE</SelectItem>
                        <SelectItem value="NÃO ATENDE">NÃO ATENDE</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    {(ticket.status === "ABERTO" || 
                      ticket.status === "EM ANÁLISE" ||
                      ticket.status === "ENVIADO E AGUARDANDO RETORNO" ||
                      (ticket.status === "ATENDE" && !ticket.dataPrincipal) ||
                      (ticket.status === "NÃO ATENDE" && !ticket.motivoNaoAtende)) && (
                      <AlertTriangle className="text-yellow-500" />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p>Nenhum ticket disponível para este perfil.</p>
        )}
      </div>
    )
  }

  const renderCrossingScreen = () => {
    return (
      <div className="mt-4">
        <div className="mb-4">
          <img src="/placeholder.svg?height=200&width=400" alt="Imóvel" className="w-full h-48 object-cover rounded-lg" />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Informação</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Imóvel</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>Identificação</TableCell>
              <TableCell>444559529</TableCell>
              <TableCell>
                <a href="https://massuhimoveis.com.br/cab-3-reformado-andar-alto-varanda-lazer-completo" className="text-blue-600 hover:underline">
                  Imóvel no site
                </a>
              </TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Nome do Contato</TableCell>
              <TableCell>Iure Brandão</TableCell>
              <TableCell></TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Telefone do Contato</TableCell>
              <TableCell>+55619783092</TableCell>
              <TableCell></TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Situação Geral</TableCell>
              <TableCell>ARQUIVAR LEAD: JÁ COMPROU</TableCell>
              <TableCell></TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Atendimento</TableCell>
              <TableCell>0.0.2 - ✓ VALIDAR OPÇÕES ( TRADICIONAL)</TableCell>
              <TableCell></TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Bairro</TableCell>
              <TableCell>Taguatinga</TableCell>
              <TableCell>Taguatinga Sul (Taguatinga)</TableCell>
              <TableCell><X className="text-red-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Observações sobre o Bairro</TableCell>
              <TableCell>Na comercial seria o ideal</TableCell>
              <TableCell></TableCell>
              <TableCell><HelpCircle className="text-yellow-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Metragem Mínima</TableCell>
              <TableCell>50,00</TableCell>
              <TableCell>83</TableCell>
              <TableCell><Check className="text-green-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Quartos</TableCell>
              <TableCell>2</TableCell>
              <TableCell>3</TableCell>
              <TableCell><Check className="text-green-500" /></TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Valor de Venda</TableCell>
              <TableCell>R$ 299.000,00</TableCell>
              <TableCell>300000</TableCell>
              <TableCell><X className="text-red-500" /></TableCell>
            </TableRow>
          </TableBody>
        </Table>
        <div className="mt-4 flex justify-end">
          <Button variant="outline">Editar Dados</Button>
        </div>
      </div>
    )
  }

  const renderTicketDetails = () => {
    if (!selectedTicket) return null;

    switch (selectedTicket.status) {
      case "ABERTO":
        return (
          <div className="mt-4">
            <p>Este ticket está aberto e aguardando ação.</p>
          </div>
        );
      case "EM ANÁLISE":
        return renderCrossingScreen();
      case "ENVIADO E AGUARDANDO RETORNO":
        return (
          <div className="mt-4">
            <Label htmlFor="tentativasCobranca">Tentativas de Cobrança</Label>
            <Select 
              onValueChange={(value) => {
                const updatedTicket = { ...selectedTicket, tentativasCobranca: value };
                setSelectedTicket(updatedTicket);
                const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                updatePendingTickets();
              }}
              value={selectedTicket.tentativasCobranca || ''}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione o número de tentativas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1</SelectItem>
                <SelectItem value="2">2</SelectItem>
                <SelectItem value="3">3</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      case "ATENDE":
        return (
          <div className="mt-4 space-y-4">
            <div className="flex space-x-4">
              <div className="flex-1">
                <Label htmlFor="dataPrincipal">Data e Hora Principal</Label>
                <Input 
                  id="dataPrincipal"
                  type="datetime-local" 
                  value={selectedTicket.dataPrincipal || ''}
                  onChange={(e) => {
                    const updatedTicket = { ...selectedTicket, dataPrincipal: e.target.value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                    updatePendingTickets();
                  }}
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="dataReserva">Data e Hora Reserva (Opcional)</Label>
                <Input 
                  id="dataReserva"
                  type="datetime-local" 
                  value={selectedTicket.dataReserva || ''}
                  onChange={(e) => {
                    const updatedTicket = { ...selectedTicket, dataReserva: e.target.value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                />
              </div>
            </div>
            {selectedTicket.dataPrincipal && (
              <div>
                <Label htmlFor="statusVisita">Status da Visita</Label>
                <Select 
                  onValueChange={(value) => {
                    const updatedTicket = { ...selectedTicket, statusVisita: value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                  value={selectedTicket.statusVisita || ''}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione o status da visita" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BUSCANDO AGENDAMENTO">BUSCANDO AGENDAMENTO</SelectItem>
                    <SelectItem value="AGENDAMENTO REALIZADO">AGENDAMENTO REALIZADO</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {selectedTicket.statusVisita === "AGENDAMENTO REALIZADO" && (
              <div>
                <Label htmlFor="statusAgendamento">Status do Agendamento</Label>
                <Select 
                  onValueChange={(value) => {
                    const updatedTicket = { ...selectedTicket, statusAgendamento: value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                  value={selectedTicket.statusAgendamento || ''}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione o status do agendamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AGUARDANDO AMBOS">AGUARDANDO AMBOS</SelectItem>
                    <SelectItem value="AGUARDANDO PROPRIETARIO / CORRETOR">AGUARDANDO PROPRIETARIO / CORRETOR</SelectItem>
                    <SelectItem value="AGUARDANDO INTERESSADO">AGUARDANDO INTERESSADO</SelectItem>
                    <SelectItem value="CONFIRMADO COM AMBOS">CONFIRMADO COM AMBOS</SelectItem>
                    <SelectItem value="VISITA OCORRIDA">VISITA OCORRIDA</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {selectedTicket.statusAgendamento === "VISITA OCORRIDA" && (
              <div>
                <Label htmlFor="resultadoVisita">Resultado da Visita</Label>
                <Select 
                  onValueChange={(value) => {
                    const updatedTicket = { ...selectedTicket, resultadoVisita: value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                  value={selectedTicket.resultadoVisita || ''}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione o resultado da visita" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem                     value="POSSIBILIDADE DE COMPRA">POSSIBILIDADE DE COMPRA</SelectItem>
                    <SelectItem value="DESCARTADO">DESCARTADO</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            {selectedTicket.resultadoVisita === "DESCARTADO" && (
              <div>
                <Label htmlFor="motivoDescarte">Motivo do Descarte</Label>
                {renderPredefinedFieldsSelector()}
              </div>
            )}
            {selectedTicket.resultadoVisita === "POSSIBILIDADE DE COMPRA" && (
              <div className="space-y-4">
                <Select 
                  onValueChange={(value) => {
                    const updatedTicket = { ...selectedTicket, statusCompra: value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData                     = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                  value={selectedTicket.statusCompra || ''}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione o status da compra" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ANALISANDO">⚠️ ANALISANDO</SelectItem>
                    <SelectItem value="ABERTURA_SONDAGEM">✅ DEU ABERTURA PARA SONDAR MENOR VALOR</SelectItem>
                    <SelectItem value="PROPOSTA_VIAVEL">✅ FORMALIZOU PROPOSTA (VALOR VIÁVEL)</SelectItem>
                    <SelectItem value="PROPOSTA_ABAIXO">⚠️ FORMALIZOU PROPOSTA (VALOR ABAIXO)</SelectItem>
                  </SelectContent>
                </Select>
                {(selectedTicket.statusCompra === "PROPOSTA_VIAVEL" || selectedTicket.statusCompra === "PROPOSTA_ABAIXO") && (
                  <div>
                    <Label htmlFor="valorProposta">Valor da Proposta</Label>
                    <Input 
                      id="valorProposta"
                      type="number" 
                      placeholder="Digite o valor da proposta"
                      value={selectedTicket.valorProposta || ''}
                      onChange={(e) => {
                        const updatedTicket = { ...selectedTicket, valorProposta: e.target.value };
                        setSelectedTicket(updatedTicket);
                        const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                        ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                      }}
                    />
                  </div>
                )}
                {(selectedTicket.statusCompra === "ABERTURA_SONDAGEM" || selectedTicket.statusCompra === "PROPOSTA_VIAVEL" || selectedTicket.statusCompra === "PROPOSTA_ABAIXO") && (
                  <div className="space-y-4">
                    <div className="flex space-x-4">
                      <div className="flex-1">
                        <Label htmlFor="tipoComissao">Tipo de Comissão</Label>
                        <Select 
                          onValueChange={(value) => {
                            const updatedTicket = { ...selectedTicket, tipoComissao: value };
                            setSelectedTicket(updatedTicket);
                            const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                            ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                          }}
                          value={selectedTicket.tipoComissao || ''}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Selecione o tipo de comissão" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="COMISSAO">COMISSÃO</SelectItem>
                            <SelectItem value="VALOR_NA_MAO">VALOR NA MÃO</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {selectedTicket.tipoComissao === "COMISSAO" && (
                        <div className="flex-1">
                          <Label htmlFor="percentualComissao">Percentual de Comissão</Label>
                          <Input 
                            id="percentualComissao"
                            type="number" 
                            placeholder="Digite o percentual"
                            value={selectedTicket.percentualComissao || ''}
                            onChange={(e) => {
                              const updatedTicket = { ...selectedTicket, percentualComissao: e.target.value };
                              setSelectedTicket(updatedTicket);
                              const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                              ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                            }}
                          />
                        </div>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="valorFinal">Valor Final</Label>
                      <Input 
                        id="valorFinal"
                        type="number" 
                        placeholder="Digite o valor final"
                        value={selectedTicket.valorFinal || ''}
                        onChange={(e) => {
                          const updatedTicket = { ...selectedTicket, valorFinal: e.target.value };
                          setSelectedTicket(updatedTicket);
                          const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                          ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="valorMargem2">Valor de Margem 2</Label>
                      <Input 
                        id="valorMargem2"
                        type="number" 
                        placeholder="Digite o valor de margem 2"
                        value={selectedTicket.valorMargem2 || ''}
                        onChange={(e) => {
                          const updatedTicket = { ...selectedTicket, valorMargem2: e.target.value };
                          setSelectedTicket(updatedTicket);
                          const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                          ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                        }}
                      />
                    </div>
                    <div>
                      <Label htmlFor="valorMargem1">Valor de Margem 1</Label>
                      <Input 
                        id="valorMargem1"
                        type="number" 
                        placeholder="Digite o valor de margem 1"
                        value={selectedTicket.valorMargem1 || ''}
                        onChange={(e) => {
                          const updatedTicket = { ...selectedTicket, valorMargem1: e.target.value };
                          setSelectedTicket(updatedTicket);
                          const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                          ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      case "NÃO ATENDE":
        return (
          <div className="mt-4 space-y-4">
            <Label htmlFor="motivoNaoAtende">Motivo de Não Atendimento</Label>
            <Select
              onValueChange={(value) => {
                const updatedTicket = { ...selectedTicket, motivoNaoAtende: value, motivoDetalhe: '' };
                setSelectedTicket(updatedTicket);
                const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                updatePendingTickets();
              }}
              value={selectedTicket.motivoNaoAtende || ''}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione o motivo" />
              </SelectTrigger>
              <SelectContent>
                {predefinedFields[currentProfileType].map((field) => (
                  <SelectItem key={field} value={field}>{field}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedTicket.motivoNaoAtende && (
              <div className="space-y-2">
                <Label htmlFor="motivoDetalhe">Detalhe do Motivo</Label>
                <Input
                  id="motivoDetalhe"
                  placeholder={`Digite o detalhe para: ${selectedTicket.motivoNaoAtende}`}
                  value={selectedTicket.motivoDetalhe || ''}
                  onChange={(e) => {
                    const updatedTicket = { ...selectedTicket, motivoDetalhe: e.target.value };
                    setSelectedTicket(updatedTicket);
                    const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                    ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  }}
                />
              </div>
            )}
            {selectedTicket.motivoNaoAtende && selectedTicket.motivoDetalhe && (
              <Button 
                onClick={() => {
                  const updatedTicket = { ...selectedTicket, status: "DESCARTADO" };
                  setSelectedTicket(updatedTicket);
                  const updatedTicketsData = ticketsData.map(t => t.id === selectedTicket.id ? updatedTicket : t);
                  ticketsData.splice(0, ticketsData.length, ...updatedTicketsData);
                  updatePendingTickets();

                  // Adicionar o motivo e detalhe ao perfil do cliente
                  const updatedClient = { ...selectedClient };
                  if (!updatedClient[currentProfileType]) {
                    updatedClient[currentProfileType] = {};
                  }
                  updatedClient[currentProfileType].motivosNaoAtende = updatedClient[currentProfileType].motivosNaoAtende || [];
                  updatedClient[currentProfileType].motivosNaoAtende.push({
                    motivo: selectedTicket.motivoNaoAtende,
                    detalhe: selectedTicket.motivoDetalhe
                  });
                  setSelectedClient(updatedClient);

                  // Atualizar o clientsData
                  const updatedClientsData = clientsData.map(c => c.id === selectedClient.id ? updatedClient : c);
                  clientsData.splice(0, clientsData.length, ...updatedClientsData);
                }}
              >
                Mover para Descartados
              </Button>
            )}
          </div>
        );
      case "DESCARTADO":
        return (
          <div className="mt-4 space-y-4">
            <div className="text-muted-foreground">
              {selectedTicket.motivoNaoAtende && (
                <>
                  <p><strong>Motivo:</strong> {selectedTicket.motivoNaoAtende}</p>
                  <p><strong>Detalhe:</strong> {selectedTicket.motivoDetalhe}</p>
                </>
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  }

  return (
    <div className={`flex h-screen ${isDarkMode ? 'dark' : ''}`}>
      {/* Left Panel (Popup) */}
      <div 
        className={`fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200 transform 
          ${isLeftPanelOpen ? 'translate-x-0' : '-translate-x-full'} 
          transition-transform duration-200 ease-in-out z-20 
          ${isFullscreen ? 'relative' : ''}`}
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-200 bg-red-600 text-white">
          <h2 className="text-lg font-semibold">Lista de Clientes</h2>
          {!isFullscreen && (
            <Button variant="ghost" size="icon" onClick={toggleLeftPanel} className="text-white hover:text-gray-200">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        <div className="p-4">
          <Input placeholder="Filtros" className="mb-4" />
          <div className="space-y-2">
            {clientsData.map((client) => (
              <div key={client.id} className="flex items-center justify-between">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-gray-700 hover:bg-gray-100"
                  onClick={() => handleClientSelect(client)}
                >
                  <span>{client.name}</span>
                </Button>
                <span
                  className="text-xs text-gray-500 cursor-pointer"
                  onDoubleClick={(e) => {
                    const input = document.createElement('input');
                    input.type = 'date';
                    input.value = client.lastEditDate.split('/').reverse().join('-');
                    input.className = 'w-32 text-xs';
                    input.onblur = (e) => {
                      handleClientDateChange(client.id, e.target.value);
                      e.target.parentNode.replaceChild(document.createTextNode(e.target.value), e.target);
                    };
                    e.target.parentNode.replaceChild(input, e.target);
                    input.focus();
                  }}
                >
                  {client.lastEditDate}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content (Right Side) */}
      <div className={`flex-1 flex flex-col ${isFullscreen && isLeftPanelOpen ? 'ml-64' : ''}`}>
        {/* Header */}
        <header className="flex justify-between items-center p-4 bg-red-600 text-white">
          <div className="flex items-center space-x-4">
            {isFullscreen ? (
              <Button variant="ghost" size="icon" onClick={toggleLeftPanel} className="text-white hover:text-gray-200">
                {isLeftPanelOpen ? <ChevronLeft className="h-6 w-6" /> : <ChevronRight className="h-6 w-6" />}
              </Button>
            ) : (
              <Button variant="ghost" size="icon" onClick={toggleLeftPanel} className="text-white hover:text-gray-200">
                <Menu className="h-6 w-6" />
              </Button>
            )}
            <h1 className="text-xl font-bold">Massuh Imóveis</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={toggleDarkMode} className="text-white hover:text-gray-200">
              {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="text-white hover:text-gray-200">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-auto bg-gray-100">
          {selectedClient ? (
            <Card className="max-w-4xl mx-auto">
              <CardHeader className="bg-red-600 text-white">
                <CardTitle>Perfil do Cliente: {selectedClient.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="personal" className="w-full" onValueChange={(value) => setCurrentProfileType(value)}>
                  <TabsList>
                    <TabsTrigger value="personal">Informações Pessoais</TabsTrigger>
                    <TabsTrigger value="propertyBuying">
                      Compra de Imóvel
                      {pendingTickets.propertyBuying > 0 && (
                        <Badge variant="destructive" className="ml-2">{pendingTickets.propertyBuying}</Badge>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="carBuying">
                      Compra de Carro
                      {pendingTickets.carBuying > 0 && (
                        <Badge variant="destructive" className="ml-2">{pendingTickets.carBuying}</Badge>
                      )}
                    </TabsTrigger>
                    <TabsTrigger  value="propertySelling">
                      Venda de Imóvel
                      {pendingTickets.propertySelling > 0 && (
                        <Badge variant="destructive" className="ml-2">{pendingTickets.propertySelling}</Badge>
                      )}
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="personal">
                    <Table>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Nome</TableCell>
                          <TableCell>{selectedClient.name}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Telefone</TableCell>
                          <TableCell>{selectedClient.phone}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Email</TableCell>
                          <TableCell>{selectedClient.email}</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Status</TableCell>
                          <TableCell>{selectedClient.status}</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </TabsContent>
                  <TabsContent value="propertyBuying">
                    <div className="flex justify-end mb-4">
                      <Button variant="outline" size="icon" onClick={handleEditToggle}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                    {isEditing ? (
                      <div className="space-y-4 mb-4">
                        {renderProfileFields()}
                      </div>
                    ) : (
                      renderTickets("propertyBuying")
                    )}
                  </TabsContent>
                  <TabsContent value="carBuying">
                    <div className="flex justify-end mb-4">
                      <Button variant="outline" size="icon" onClick={handleEditToggle}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                    {isEditing ? (
                      <div className="space-y-4 mb-4">
                        {renderProfileFields()}
                      </div>
                    ) : (
                      renderTickets("carBuying")
                    )}
                  </TabsContent>
                  <TabsContent value="propertySelling">
                    <div className="flex justify-end mb-4">
                      <Button variant="outline" size="icon" onClick={handleEditToggle}>
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                    {isEditing ? (
                      <div className="space-y-4 mb-4">
                        {renderProfileFields()}
                      </div>
                    ) : (
                      renderTickets("propertySelling")
                    )}
                  </TabsContent>
                </Tabs>
                {selectedTicket && !isEditing && (
                  <Card className="mt-4">
                    <CardHeader>
                      <CardTitle>Detalhes do Ticket</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {renderTicketDetails()}
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-xl text-gray-500">Selecione um cliente para ver os detalhes</p>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}